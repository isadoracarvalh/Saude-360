import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomePage from '../Pages/HomePage';
import TratamentosPage from '../Pages/TratamentosPage';
import HistoricoPage from '../Pages/HistoricoPage';
import NotificacoesPage from '../Pages/NotificacoesPage';

const Tab = createBottomTabNavigator();

const BottomTabNavigator = () => {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Início" component={HomePage} />
      <Tab.Screen name="Tratamentos" component={TratamentosPage} />
      <Tab.Screen name="Histórico" component={HistoricoPage} />
      <Tab.Screen name="Notificações" component={NotificacoesPage} />
    </Tab.Navigator>
  );
};

export default BottomTabNavigator;
