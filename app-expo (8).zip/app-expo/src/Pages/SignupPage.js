import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  Modal,
  StyleSheet,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';

export default function App() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [birthdate, setBirthdate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [gender, setGender] = useState('');
  const [showGenderPicker, setShowGenderPicker] = useState(false);
  const [discovery, setDiscovery] = useState('');
  const [showDiscoveryPicker, setShowDiscoveryPicker] = useState(false);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSignup = async () => {
    if (!isValidEmail(email)) {
      Alert.alert('Erro', 'Email inválido.');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('Erro', 'As senhas não correspondem.');
      return;
    }

    Alert.alert('Sucesso', 'Cadastro realizado com sucesso!');
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.header}>Cadastro</Text>
        <TextInput
          style={styles.input}
          placeholder="Nome"
          value={name}
          onChangeText={setName}
        />
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />
        <TouchableOpacity onPress={() => setShowDatePicker(true)}>
          <TextInput
            style={styles.input}
            placeholder="Data de Nascimento"
            value={birthdate.toLocaleDateString()}
            editable={false}
          />
        </TouchableOpacity>
        {showDatePicker && (
          <DateTimePicker
            value={birthdate}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              const currentDate = selectedDate || birthdate;
              setShowDatePicker(Platform.OS === 'ios');
              setBirthdate(currentDate);
            }}
          />
        )}
        <TouchableOpacity onPress={() => setShowGenderPicker(true)}>
          <TextInput
            style={styles.input}
            placeholder="Qual seu gênero?"
            value={gender ? gender : ''}
            editable={false}
          />
        </TouchableOpacity>
        <Modal
          visible={showGenderPicker}
          transparent={true}
          animationType="slide">
          <View style={styles.modalContainer}>
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={gender}
                onValueChange={(itemValue) => {
                  setGender(itemValue);
                  setShowGenderPicker(false);
                }}>
                <Picker.Item label="Selecione seu gênero" value="" />
                <Picker.Item label="Feminino" value="Genêro feminino" />
                <Picker.Item label="Masculino" value="Genêro masculino" />
                <Picker.Item label="Outro" value="Outro" />
              </Picker>
              <Button
                title="Confirmar"
                onPress={() => setShowGenderPicker(false)}
              />
            </View>
          </View>
        </Modal>
        <TouchableOpacity onPress={() => setShowDiscoveryPicker(true)}>
          <TextInput
            style={styles.input}
            placeholder="Como conheceu o app?"
            value={discovery ? discovery : ''}
            editable={false}
          />
        </TouchableOpacity>
        <Modal
          visible={showDiscoveryPicker}
          transparent={true}
          animationType="slide">
          <View style={styles.modalContainer}>
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={discovery}
                onValueChange={(itemValue) => {
                  setDiscovery(itemValue);
                  setShowDiscoveryPicker(false);
                }}>
                <Picker.Item label="Selecione uma opção" value="" />
                <Picker.Item
                  label="Conhecidos"
                  value="Conheci por Conhecidos"
                />
                <Picker.Item
                  label="Alguém da área da saúde/local"
                  value="Conheci por alguém da área da saúde/local"
                />
                <Picker.Item label="Anúncios" value="Conheci por anúncios" />
                <Picker.Item
                  label="Outros"
                  value="Conheci por outros motivos"
                />
              </Picker>
              <Button
                title="Confirmar"
                onPress={() => setShowDiscoveryPicker(false)}
              />
            </View>
          </View>
        </Modal>
        <TextInput
          style={styles.input}
          placeholder="Senha"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
        <TextInput
          style={styles.input}
          placeholder="Confirmar Senha"
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          secureTextEntry
        />
        <Button title="Cadastrar" onPress={handleSignup} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'stretch',
    justifyContent: 'center',
    padding: 16,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    alignSelf: 'center',
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
    width: '100%',
    borderRadius: 10,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  pickerContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    width: '80%',
  },
});
