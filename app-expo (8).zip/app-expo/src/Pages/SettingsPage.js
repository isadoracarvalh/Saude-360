import React from 'react';
import { View, Text, Button } from 'react-native';
import styles from '../styles/styles';

const SettingsPage = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Settings Page</Text>
      <Text>This is the settings page.</Text>
      <Button title="Logout" onPress={() => navigation.navigate('Login')} />
    </View>
  );
};

export default SettingsPage;
