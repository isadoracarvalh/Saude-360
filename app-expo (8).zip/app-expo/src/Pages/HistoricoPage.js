import React from 'react';
import { View, Text } from 'react-native';
import styles from '../styles/styles';

const HistoricoPage = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Histórico</Text>
      <Text style={styles.text}>Aqui você verá o histórico do paciente.</Text>
    </View>
  );
};

export default HistoricoPage;
