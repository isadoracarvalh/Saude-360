import React, { useState, useEffect } from 'react';
import { View, Text, Button, TextInput } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from '../styles/styles';

const ManagePreferencesPage = () => {
  const [preference, setPreference] = useState('');

  useEffect(() => {
    loadPreference();
  }, []);

  const loadPreference = async () => {
    try {
      const value = await AsyncStorage.getItem('userPreference');
      if (value !== null) {
        setPreference(value);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const savePreference = async () => {
    try {
      await AsyncStorage.setItem('userPreference', preference);
      alert('Preference saved!');
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Manage Preferences</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your preference"
        value={preference}
        onChangeText={setPreference}
      />
      <Button title="Save Preference" onPress={savePreference} />
    </View>
  );
};

export default ManagePreferencesPage;
