import React from 'react';
import { View, Text } from 'react-native';
import styles from '../styles/styles';

const NotificacoesPage = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Notificações</Text>
      <Text style={styles.text}>Aqui você verá suas notificações.</Text>
    </View>
  );
};

export default NotificacoesPage;
