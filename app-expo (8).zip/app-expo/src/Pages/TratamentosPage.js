import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center', // Centraliza horizontalmente
    justifyContent: 'flex-start', // Começa no topo da página
    padding: 16,
  },
  logo: {
    width: 120,
    height: 120,
    marginBottom: 30,
    resizeMode: 'contain',
    alignSelf: 'center', // Centraliza horizontalmente
  },
  loginLogo: {
    width: 120,
    height: 120,
    marginBottom: 30,
    marginTop: 50, // Ajuste conforme necessário
    resizeMode: 'contain',
    alignSelf: 'center', // Centraliza horizontalmente
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    alignSelf: 'center', // Centraliza horizontalmente
  },
  subHeader: {
    fontSize: 20,
    fontWeight: 'normal',
    marginBottom: 8,
    alignSelf: 'center', // Centraliza horizontalmente
  },
  text: {
    fontSize: 16,
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
    width: '100%',
    borderRadius: 10, // Torna os campos arredondados
  },
  eyeIcon: {
    position: 'absolute',
    top: 10,
    right: 10,
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    marginBottom: 10,
  },
  errorText: {
    color: 'red',
    marginBottom: 10,
    textAlign: 'center',
  },
  buttonContainer: {
    width: '100%',
    marginTop: 20,
  },
  button: {
    backgroundColor: '#0000FF', // Cor do botão de entrada
    padding: 10,
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
  },
  linkText: {
    color: '#0000FF',
    marginTop: 10,
    textAlign: 'center',
  },
});
