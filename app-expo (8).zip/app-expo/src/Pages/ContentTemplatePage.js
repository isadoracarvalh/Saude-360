import React from 'react';
import { View, Text } from 'react-native';
import styles from '../styles/styles';

const ContentTemplatePage = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Content Template Page</Text>
      <Text>This is the content template page.</Text>
    </View>
  );
};

export default ContentTemplatePage;
