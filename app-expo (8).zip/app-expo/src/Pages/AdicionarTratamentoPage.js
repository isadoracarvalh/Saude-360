import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import styles from '../styles/styles';

const AdicionarTratamentoPage = ({ navigation }) => {
  const [nome, setNome] = useState('');
  const [horario, setHorario] = useState('');

  const handleAddTreatment = () => {
    // Aqui você pode adicionar a lógica para salvar o tratamento
    Alert.alert('Tratamento Adicionado', `Tratamento ${nome} adicionado com sucesso!`);
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Adicionar Tratamento</Text>
      <TextInput
        style={styles.input}
        placeholder="Nome do Tratamento"
        value={nome}
        onChangeText={setNome}
      />
      <TextInput
        style={styles.input}
        placeholder="Horário"
        value={horario}
        onChangeText={setHorario}
      />
      <Button title="Adicionar" onPress={handleAddTreatment} />
    </View>
  );
};

export default AdicionarTratamentoPage;
