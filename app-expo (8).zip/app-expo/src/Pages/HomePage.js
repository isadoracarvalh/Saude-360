import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, FlatList, Button } from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from '../styles/styles';

const HomePage = ({ navigation }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userName, setUserName] = useState('');

  useEffect(() => {
    fetchUserData();
    fetchData();
  }, []);

  const fetchUserData = async () => {
    try {
      const userDataString = await AsyncStorage.getItem('@userData');
      if (userDataString) {
        const userData = JSON.parse(userDataString);
        setUserName(userData.name);
      }
    } catch (error) {
      console.error('Erro ao recuperar dados do usuário:', error);
    }
  };

  const fetchData = async () => {
    try {
      const response = await axios.get('https://api.example.com/data');
      setData(response.data);
      setLoading(false);
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Saúde360</Text>
      <Text style={styles.subHeader}>Olá, {userName}! Como está se sentindo hoje?</Text>
      <Text style={styles.text}>Acompanhe a sua saúde física e mental.</Text>
      <FlatList
        data={data}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text>{item.title}</Text>
            <Text>{item.description}</Text>
          </View>
        )}
      />
      <Button
        title="Adicionar Tratamento"
        onPress={() => navigation.navigate('Tratamentos')}
      />
    </View>
  );
};

export default HomePage;
