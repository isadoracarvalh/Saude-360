import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from '../styles/styles';

const MiniQuizPage = ({ navigation }) => {
  const [diseaseHistory, setDiseaseHistory] = useState('');
  const [dailyHabits, setDailyHabits] = useState('');
  const [familyDiseases, setFamilyDiseases] = useState('');

  const handleQuizSubmit = async () => {
    try {
      const userDataString = await AsyncStorage.getItem('@userData');
      if (userDataString) {
        const userData = JSON.parse(userDataString);
        const updatedUserData = {
          ...userData,
          diseaseHistory,
          dailyHabits,
          familyDiseases,
        };
        await AsyncStorage.setItem('@userData', JSON.stringify(updatedUserData));
        Alert.alert('Sucesso', 'Informações do quiz salvas com sucesso!');
        navigation.navigate('Main');
      } else {
        Alert.alert('Erro', 'Usuário não encontrado. Faça o login novamente.');
      }
    } catch (error) {
      console.error('Erro ao salvar informações do quiz:', error);
      Alert.alert('Erro', 'Não foi possível salvar as informações. Tente novamente.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Mini Quiz</Text>
      <Text>Primeiro, vamos falar do seu histórico</Text>
      <TextInput
        style={styles.input}
        placeholder="Doenças que você possui"
        value={diseaseHistory}
        onChangeText={setDiseaseHistory}
      />
      <Text>E agora sobre seus hábitos diários</Text>
      <TextInput
        style={styles.input}
        placeholder="Seus hábitos diários"
        value={dailyHabits}
        onChangeText={setDailyHabits}
      />
      <Text>Por último, sobre doenças na sua família</Text>
      <TextInput
        style={styles.input}
        placeholder="Doenças na sua família"
        value={familyDiseases}
        onChangeText={setFamilyDiseases}
      />
      <Button title="Salvar e Continuar" onPress={handleQuizSubmit} />
    </View>
  );
};

export default MiniQuizPage;
