import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import LoadingPage from './src/Pages/LoadingPage';
import LoginPage from './src/Pages/LoginPage';
import SignupPage from './src/Pages/SignupPage';
import BottomTabNavigator from './src/navigation/BottomTabNavigator';
import MiniQuizPage from './src/Pages/MiniQuizPage';
import TratamentosPage from './src/Pages/TratamentosPage';
import AdicionarTratamentoPage from './src/Pages/AdicionarTratamentoPage';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Loading">
        <Stack.Screen name="Loading" component={LoadingPage} options={{ headerShown: false }} />
        <Stack.Screen name="Login" component={LoginPage} options={{ headerShown: false }} />
        <Stack.Screen name="Signup" component={SignupPage} options={{ headerShown: false }} />
        <Stack.Screen name="Main" component={BottomTabNavigator} options={{ headerShown: false }} />
        <Stack.Screen name="MiniQuiz" component={MiniQuizPage} options={{ headerShown: false }} />
        <Stack.Screen name="Tratamentos" component={TratamentosPage} options={{ headerShown: false }} />
        <Stack.Screen name="AdicionarTratamento" component={AdicionarTratamentoPage} options={{ headerShown: false }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
